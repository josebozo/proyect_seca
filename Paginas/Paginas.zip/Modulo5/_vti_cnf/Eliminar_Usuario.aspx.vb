vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Oct 2002 21:36:36 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|31 Oct 2002 21:36:36 -0000
vti_filesize:IR|5029
