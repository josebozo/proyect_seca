vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Oct 2002 20:24:38 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|24 Oct 2002 20:24:38 -0000
vti_filesize:IR|5418
