vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Oct 2002 22:56:00 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|31 Oct 2002 22:56:00 -0000
vti_filesize:IR|3020
