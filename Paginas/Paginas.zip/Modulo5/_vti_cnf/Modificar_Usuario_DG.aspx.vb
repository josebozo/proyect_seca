vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Nov 2002 20:16:58 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|07 Nov 2002 20:16:58 -0000
vti_filesize:IR|3336
