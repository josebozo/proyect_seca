vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Aug 2002 17:23:32 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|11 Oct 2002 03:36:32 -0000
vti_filesize:IR|1742
