vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Aug 2002 14:53:22 -0000
vti_extenderversion:SR|4.0.2.6513
vti_lineageid:SR|{23794D55-9F54-43C5-814A-5260AC51097C}
vti_cacheddtm:TX|11 Oct 2002 02:34:30 -0000
vti_filesize:IR|996
vti_backlinkinfo:VX|
