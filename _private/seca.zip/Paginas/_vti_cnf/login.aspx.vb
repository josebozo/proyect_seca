vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Aug 2002 19:32:22 -0000
vti_extenderversion:SR|4.0.2.6513
vti_lineageid:SR|{90775000-7F28-4BD2-978B-DDF78E680DB6}
vti_cacheddtm:TX|12 Oct 2002 02:50:24 -0000
vti_filesize:IR|1536
vti_backlinkinfo:VX|
