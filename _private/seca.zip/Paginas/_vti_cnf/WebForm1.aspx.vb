vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Aug 2002 02:20:16 -0000
vti_extenderversion:SR|4.0.2.6513
vti_lineageid:SR|{3994E846-0350-4156-8029-ABD6597FE7B8}
vti_cacheddtm:TX|08 Aug 2002 02:20:16 -0000
vti_filesize:IR|735
vti_backlinkinfo:VX|
