Public Class intro2
    Inherits System.Web.UI.Page
    Protected WithEvents Grid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents SqlDataAdapter1 As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents Grid2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents SqlDataAdapter2 As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
    Protected WithEvents Conn As System.Data.SqlClient.SqlConnection

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SqlDataAdapter1 = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.Conn = New System.Data.SqlClient.SqlConnection()
        Me.SqlDataAdapter2 = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand()
        '
        'SqlDataAdapter1
        '
        Me.SqlDataAdapter1.SelectCommand = Me.SqlSelectCommand1
        Me.SqlDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "SECA_evaluacion_citas", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Nombre del Alumno", "Nombre del Alumno"), New System.Data.Common.DataColumnMapping("Evaluacion", "Evaluacion"), New System.Data.Common.DataColumnMapping("Fecha de la Evaluacion", "Fecha de la Evaluacion")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT [Nombre del Alumno], Evaluacion, [Fecha de la Evaluacion] FROM dbo.SECA_ev" & _
        "aluacion_citas"
        Me.SqlSelectCommand1.Connection = Me.Conn
        '
        'Conn
        '
        Me.Conn.ConnectionString = "data source=bozoxp06;initial catalog=SECA_DB;persist security info=False;user id=" & _
        "reporte;workstation id=BOZOXP06;packet size=4096"
        '
        'SqlDataAdapter2
        '
        Me.SqlDataAdapter2.SelectCommand = Me.SqlSelectCommand2
        Me.SqlDataAdapter2.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "SECA_comentarios", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("�rea", "�rea"), New System.Data.Common.DataColumnMapping("Alumno", "Alumno"), New System.Data.Common.DataColumnMapping("Observaci�n", "Observaci�n"), New System.Data.Common.DataColumnMapping("Fecha", "Fecha")})})
        '
        'SqlSelectCommand2
        '
        Me.SqlSelectCommand2.CommandText = "SELECT Area AS �rea, Apellido + ', " & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "    ' + Nombre AS Alumno, observacion AS Obs" & _
        "ervaci�n, Fecha FROM SECA_comentarios ORDER BY alumno"
        Me.SqlSelectCommand2.Connection = Me.Conn

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If (Page.IsPostBack = False) Then
            Dim DS As System.Data.DataSet
            Dim DS2 As System.Data.DataSet
            DS = New System.Data.DataSet()
            DS2 = New System.Data.DataSet()
            SqlDataAdapter1.Fill(DS, "Tables")
            SqlDataAdapter2.Fill(DS2, "Tables")
            Grid1.DataSource = DS.Tables("Tables").DefaultView
            Grid2.DataSource = DS2.Tables("Tables").DefaultView
            Grid1.DataBind()
            Grid2.DataBind()
        End If
    End Sub

    Private Sub Grid1_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles Grid1.PageIndexChanged
        Grid1.CurrentPageIndex = e.NewPageIndex
        Dim DS As System.Data.DataSet
        DS = New System.Data.DataSet()
        SqlDataAdapter1.Fill(DS, "Tables")
        Grid1.DataSource = DS.Tables("Tables").DefaultView
        Grid1.DataBind()
    End Sub


    Private Sub Grid1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles Grid1.SortCommand
        Dim DS As System.Data.DataSet
        DS = New System.Data.DataSet()
        SqlDataAdapter1.Fill(DS, "Tables")
        DS.Tables("tables").DefaultView.Sort = e.SortExpression.ToString
        Grid1.DataSource = DS.Tables("Tables").DefaultView
        Grid1.DataBind()
    End Sub

    Private Sub Grid2_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles Grid2.PageIndexChanged
        Grid2.CurrentPageIndex = e.NewPageIndex
        Dim DS2 As System.Data.DataSet
        DS2 = New System.Data.DataSet()
        SqlDataAdapter2.Fill(DS2, "Tables")
        Grid2.DataSource = DS2.Tables("Tables").DefaultView
        Grid2.DataBind()
    End Sub

    Private Sub Grid2_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles Grid2.SortCommand
        Dim DS2 As System.Data.DataSet
        DS2 = New System.Data.DataSet()
        SqlDataAdapter2.Fill(DS2, "Tables")
        DS2.Tables("tables").DefaultView.Sort = e.SortExpression.ToString
        Grid2.DataSource = DS2.Tables("Tables").DefaultView
        Grid2.DataBind()
    End Sub


End Class
