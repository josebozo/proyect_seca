vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|04 Sep 2002 17:53:22 -0000
vti_extenderversion:SR|4.0.2.6513
vti_lineageid:SR|{6E893CCC-0417-4432-B0DE-9FE878A1DB88}
vti_cacheddtm:TX|10 Oct 2002 02:58:28 -0000
vti_filesize:IR|10876
vti_backlinkinfo:VX|
