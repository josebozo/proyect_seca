vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|04 Sep 2002 19:11:14 -0000
vti_extenderversion:SR|4.0.2.6513
vti_lineageid:SR|{1C0BB687-0A4F-4D10-B275-6EED74931F46}
vti_cacheddtm:TX|10 Oct 2002 02:58:26 -0000
vti_filesize:IR|7263
vti_backlinkinfo:VX|
vti_modifiedby:SR|BOZOXP06\\Jose
