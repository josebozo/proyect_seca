vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Oct 2002 02:58:26 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|10 Oct 2002 02:58:26 -0000
vti_filesize:IR|3114
