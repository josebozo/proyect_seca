vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Oct 2002 23:58:14 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|11 Oct 2002 23:58:14 -0000
vti_filesize:IR|4840
