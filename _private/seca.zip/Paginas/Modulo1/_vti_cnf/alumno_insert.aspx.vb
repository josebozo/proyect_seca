vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Aug 2002 17:02:28 -0000
vti_extenderversion:SR|4.0.2.6513
vti_lineageid:SR|{BB29A5CA-C971-46CE-921C-9298366F75FA}
vti_cacheddtm:TX|12 Oct 2002 00:03:20 -0000
vti_filesize:IR|8624
vti_backlinkinfo:VX|
