vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Sep 2002 06:29:34 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|23 Sep 2002 06:29:34 -0000
vti_filesize:IR|3189
