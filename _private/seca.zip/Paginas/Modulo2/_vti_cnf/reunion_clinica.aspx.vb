vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Sep 2002 08:04:50 -0000
vti_extenderversion:SR|4.0.2.6513
vti_cacheddtm:TX|23 Sep 2002 08:04:50 -0000
vti_filesize:IR|1202
